import json.JSONArray;
import json.JSONObject;

public class SocialBot {
    private String username;
    private String passwort;
    private NetzwerkZugriff socialbotnet;

    public SocialBot(String username2, String passwort2) {
        username = username2;
        passwort = passwort2;
        socialbotnet = new NetzwerkZugriff("https://www.socialbotnet.de");
    }

    public void posten(String nachricht) {
        /**
         * Erg�nze hier den Code, damit der Bot im Netzwerk posten kann. 
         */
    }
    
    /**
     * Schreibe weitere Funktionen f�r den Bot
     */
}
