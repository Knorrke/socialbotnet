import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;

public class NetzwerkZugriff {
    private String domain;
    private ArrayList<String> parameter = new ArrayList<String>();

    public NetzwerkZugriff(String domainName) {
        domain = domainName;
    }

    public void POSTAnfrageVorbereiten(String schluessel, Object daten) {
        try {
            parameter.add(URLEncoder.encode(schluessel, "UTF-8") + "=" + URLEncoder.encode(daten.toString(), "UTF-8"));
        } catch (Exception ignore) {}
    }

    public void POSTAnfrageSenden(String url) {
        try {
            URL urlobj = new URL(domain + url);
            HttpURLConnection verbindung = (HttpURLConnection) urlobj.openConnection();
            verbindung.setRequestMethod("POST");

            StringBuilder anfrageBuilder = new StringBuilder();
            for (int i = 0; i < parameter.size(); i++) {				
                if ( i != 0) {
                    anfrageBuilder.append('&');
                }
                anfrageBuilder.append(parameter.get(i));
            }
            String urlParameter = anfrageBuilder.toString();

            // Send post request
            verbindung.setDoOutput(true);

            PrintWriter writer = new PrintWriter(verbindung.getOutputStream());
            writer.print(urlParameter);
            writer.flush();
            writer.close();
            parameter = new ArrayList<String>();

            int responseCode = verbindung.getResponseCode();

            System.out.println("\nSende 'POST'-Anfrage an URL : " + url);
            System.out.println("POST Parameter : " + urlParameter);
            System.out.println("Die Antwort hat den Status : " + responseCode + " " + verbindung.getResponseMessage());

            BufferedReader in;

            if (responseCode == 200) {
                in = new BufferedReader(new InputStreamReader(verbindung.getInputStream()));
            } else {
                in = new BufferedReader(new InputStreamReader(verbindung.getErrorStream()));
            }
            String inputZeile;
            StringBuffer antwortBuffer = new StringBuffer();

            while ((inputZeile = in.readLine()) != null) {
                antwortBuffer.append(inputZeile);
            }
            in.close();

            System.out.println(antwortBuffer.toString());

        } catch (MalformedURLException e) {
            System.out.println("Fehlerhafte URL " + domain + url);
            System.out.println("Vielleicht hast du http:// oder https:// vergessen?");
        } catch (ProtocolException e1) {
            e1.printStackTrace();
        } catch (IOException e) {
            System.out.println("Bei der Verbindung ist etwas schief gegangen: " + e.getMessage());
        }
    }

    public String GETAnfrageSenden(String url) {
        String antwort = "";
        try {
            URL urlobj = new URL(domain + url);
            HttpURLConnection verbindung = (HttpURLConnection) urlobj.openConnection(); 
            verbindung.setRequestMethod("GET");

            int responseCode = verbindung.getResponseCode();
            System.out.println("\nSende 'GET'-Anfrage an URL : " + url);
            System.out.println("Die Antwort hat den Statuscode : " + responseCode + " " + verbindung.getResponseMessage());

            BufferedReader in = new BufferedReader(new InputStreamReader(verbindung.getInputStream()));
            String inputZeile;
            StringBuffer antwortBuffer = new StringBuffer();

            while ((inputZeile = in.readLine()) != null) {
                antwortBuffer.append(inputZeile);
            }
            in.close();

            antwort = antwortBuffer.toString();

        } catch (MalformedURLException e) {
            System.out.println("Fehlerhafte URL " + domain + url);
            System.out.println("Vielleicht hast du http:// oder https:// vergessen?");
        } catch (ProtocolException e1) {
            e1.printStackTrace();
        } catch (IOException e) {
            System.out.println("Bei der Verbindung ist etwas schief gegangen: " + e.getMessage());
            System.out.println("Antwort: " + antwort);
        }

        System.out.println(antwort);
        return antwort;
    }
}
